import { useEffect, useRef } from 'react';

const API_BASE = 'http://localhost:5000';

export const useSSE = (onMessage, online) => {
  const eventSourceRef = useRef(null);

  useEffect(() => {
    if (!online) return;

    const connectSSE = () => {
      eventSourceRef.current = new EventSource(`${API_BASE}/events`);

      eventSourceRef.current.onmessage = (event) => {
        try {
          const newTicket = JSON.parse(event.data);
          onMessage(newTicket);
        } catch (error) {
          console.error('Error parsing SSE message:', error);
        }
      };

      eventSourceRef.current.onerror = (error) => {
        console.error('SSE error:', error);
        eventSourceRef.current?.close();
        
        // Reconnect after 5 seconds
        setTimeout(connectSSE, 5000);
      };
    };

    connectSSE();

    return () => {
      eventSourceRef.current?.close();
    };
  }, [onMessage, online]);
};