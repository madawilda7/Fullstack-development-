import { useState, useEffect, useCallback } from 'react';
import { IndexedDBService } from '../utils/indexedDB';

const API_BASE = 'http://localhost:5000';

export const useTickets = () => {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [online, setOnline] = useState(navigator.onLine);
  const [db, setDb] = useState(null);

  useEffect(() => {
    const initDB = async () => {
      const dbService = new IndexedDBService();
      await dbService.init();
      setDb(dbService);
    };

    initDB();
  }, []);

  useEffect(() => {
    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadTickets = useCallback(async () => {
    if (!db) return;

    try {
      if (online) {
        // Load from server when online
        const response = await fetch(`${API_BASE}/tickets`);
        const serverTickets = await response.json();
        setTickets(serverTickets);

        // Sync local DB with server
        for (const ticket of serverTickets) {
          await db.addTicket(ticket);
        }
      } else {
        // Load from IndexedDB when offline
        const localTickets = await db.getAllTickets();
        setTickets(localTickets);
      }
    } catch (error) {
      console.error('Error loading tickets:', error);
      // Fallback to local DB
      const localTickets = await db.getAllTickets();
      setTickets(localTickets);
    } finally {
      setLoading(false);
    }
  }, [db, online]);

  useEffect(() => {
    loadTickets();
  }, [loadTickets]);

  const syncPendingTickets = useCallback(async () => {
    if (!db || !online) return;

    try {
      const pendingTickets = await db.getPendingSync();
      
      for (const pendingTicket of pendingTickets) {
        try {
          const response = await fetch(`${API_BASE}/tickets`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(pendingTicket),
          });

          if (response.ok) {
            // Remove from pending sync on success
            await db.clearPendingSync();
          }
        } catch (error) {
          console.error('Error syncing ticket:', error);
        }
      }
    } catch (error) {
      console.error('Error during sync:', error);
    }
  }, [db, online]);

  useEffect(() => {
    if (online) {
      syncPendingTickets();
    }
  }, [online, syncPendingTickets]);

  const createTicket = async (ticketData) => {
    const newTicket = {
      ...ticketData,
      id: Date.now().toString(), // Temporary ID for offline
      createdAt: new Date().toISOString(),
    };

    // Always add to local DB first
    if (db) {
      await db.addTicket(newTicket);
      setTickets(prev => [...prev, newTicket]);
    }

    if (online) {
      try {
        const response = await fetch(`${API_BASE}/tickets`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(ticketData),
        });

        if (!response.ok) throw new Error('Failed to create ticket');
      } catch (error) {
        console.error('Error creating ticket online, queuing for sync:', error);
        if (db) {
          await db.addPendingSync(ticketData);
        }
      }
    } else {
      // Queue for sync when online
      if (db) {
        await db.addPendingSync(ticketData);
      }
    }
  };

  return {
    tickets,
    loading,
    online,
    createTicket,
    refreshTickets: loadTickets,
  };
};