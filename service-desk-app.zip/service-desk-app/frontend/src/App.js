import React, { useState, useCallback } from 'react';
import { useTickets } from './hooks/useTickets';
import { useSSE } from './hooks/useSSE';
import TicketForm from './components/TicketForm';
import TicketList from './components/TicketList';
import './App.css';

function App() {
  const { tickets, loading, online, createTicket, refreshTickets } = useTickets();
  const [filters, setFilters] = useState({
    search: '',
    priority: 'ALL'
  });

  // Handle SSE messages for live updates
  const handleNewTicket = useCallback((newTicket) => {
    refreshTickets(); // Refresh the list when new ticket arrives via SSE
  }, [refreshTickets]);

  useSSE(handleNewTicket, online);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  if (loading) {
    return <div className="app-loading">Loading...</div>;
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>Service Desk Queue</h1>
        <p>Manage support tickets with offline capability</p>
      </header>

      <div className="app-content">
        <div className="left-panel">
          <TicketForm onCreateTicket={createTicket} online={online} />
        </div>
        
        <div className="right-panel">
          <TicketList 
            tickets={tickets}
            filters={filters}
            onFilterChange={handleFilterChange}
            online={online}
          />
        </div>
      </div>
    </div>
  );
}

export default App;