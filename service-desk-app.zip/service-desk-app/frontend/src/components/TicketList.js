import React from 'react';

const TicketList = ({ tickets, filters, onFilterChange, online }) => {
  const filteredTickets = tickets.filter(ticket => {
    if (filters.priority && filters.priority !== 'ALL' && ticket.priority !== filters.priority) {
      return false;
    }
    if (filters.search && !ticket.title.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    return true;
  });

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH': return '#ff4444';
      case 'MEDIUM': return '#ffaa00';
      case 'LOW': return '#44ff44';
      default: return '#cccccc';
    }
  };

  return (
    <div className="ticket-list">
      <div className="filters">
        <input
          type="text"
          placeholder="Search tickets..."
          value={filters.search}
          onChange={(e) => onFilterChange('search', e.target.value)}
        />
        
        <select 
          value={filters.priority} 
          onChange={(e) => onFilterChange('priority', e.target.value)}
        >
          <option value="ALL">All Priorities</option>
          <option value="HIGH">High</option>
          <option value="MEDIUM">Medium</option>
          <option value="LOW">Low</option>
        </select>

        <div className="online-status">
          Status: {online ? '🟢 Online' : '🔴 Offline'}
        </div>
      </div>

      <div className="tickets">
        {filteredTickets.map(ticket => (
          <div key={ticket.id} className="ticket-card">
            <div className="ticket-header">
              <h4>{ticket.title}</h4>
              <span 
                className="priority-badge"
                style={{ backgroundColor: getPriorityColor(ticket.priority) }}
              >
                {ticket.priority}
              </span>
            </div>
            <div className="ticket-details">
              <span className="category">Category: {ticket.category}</span>
              <span className="created-at">
                {new Date(ticket.createdAt).toLocaleString()}
              </span>
            </div>
          </div>
        ))}
        
        {filteredTickets.length === 0 && (
          <div className="no-tickets">No tickets found</div>
        )}
      </div>
    </div>
  );
};

export default TicketList;