import React, { useState } from 'react';

const TicketForm = ({ onCreateTicket, online }) => {
  const [formData, setFormData] = useState({
    title: '',
    priority: 'MEDIUM',
    category: 'Technical'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    onCreateTicket(formData);
    setFormData({
      title: '',
      priority: 'MEDIUM',
      category: 'Technical'
    });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <form onSubmit={handleSubmit} className="ticket-form">
      <h3>Create New Ticket</h3>
      <div className="form-group">
        <input
          type="text"
          name="title"
          placeholder="Ticket title"
          value={formData.title}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="form-group">
        <select name="priority" value={formData.priority} onChange={handleChange}>
          <option value="LOW">Low Priority</option>
          <option value="MEDIUM">Medium Priority</option>
          <option value="HIGH">High Priority</option>
        </select>
      </div>

      <div className="form-group">
        <select name="category" value={formData.category} onChange={handleChange}>
          <option value="Technical">Technical</option>
          <option value="Billing">Billing</option>
          <option value="General">General</option>
          <option value="Hardware">Hardware</option>
        </select>
      </div>

      <button type="submit" disabled={!formData.title.trim()}>
        Create Ticket {!online && '(Offline)'}
      </button>
    </form>
  );
};

export default TicketForm;