const CACHE_NAME = 'service-desk-v1';
const API_BASE = 'http://localhost:5000';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Cache API requests
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then(response => {
          // Clone the response to cache it
          const responseToCache = response.clone();
          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(request, responseToCache);
            });
          return response;
        })
        .catch(() => {
          // When offline, return cached version
          return caches.match(request);
        })
    );
  } else {
    // For other requests, try network first
    event.respondWith(
      fetch(request)
        .catch(() => caches.match(request))
    );
  }
});