const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// In-memory storage with file persistence
const DATA_FILE = path.join(__dirname, 'tickets.json');

// Initialize data file if it doesn't exist
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify([]));
}

// Helper functions for data persistence
const readTickets = () => {
  try {
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading tickets:', error);
    return [];
  }
};

const writeTickets = (tickets) => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(tickets, null, 2));
  } catch (error) {
    console.error('Error writing tickets:', error);
  }
};

// SSE clients
let clients = [];

// Routes
app.get('/tickets', (req, res) => {
  const { priority, q } = req.query;
  let tickets = readTickets();

  // Filter by priority
  if (priority && priority !== 'ALL') {
    tickets = tickets.filter(ticket => ticket.priority === priority);
  }

  // Search by title
  if (q) {
    tickets = tickets.filter(ticket => 
      ticket.title.toLowerCase().includes(q.toLowerCase())
    );
  }

  res.json(tickets);
});

app.post('/tickets', (req, res) => {
  const { title, priority, category } = req.body;
  
  if (!title || !priority || !category) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const tickets = readTickets();
  const newTicket = {
    id: uuidv4(),
    title,
    priority: priority.toUpperCase(),
    category,
    createdAt: new Date().toISOString()
  };

  tickets.push(newTicket);
  writeTickets(tickets);

  // Notify all SSE clients
  clients.forEach(client => 
    client.res.write(`data: ${JSON.stringify(newTicket)}\n\n`)
  );

  res.status(201).json(newTicket);
});

// SSE endpoint for live updates
app.get('/events', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Connection': 'keep-alive',
    'Cache-Control': 'no-cache',
    'Access-Control-Allow-Origin': '*'
  });

  const clientId = Date.now();
  const newClient = {
    id: clientId,
    res
  };

  clients.push(newClient);

  req.on('close', () => {
    clients = clients.filter(client => client.id !== clientId);
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});