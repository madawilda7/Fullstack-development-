# Inventory Management System

A full-stack inventory management system with role-based access control (RBAC) and JWT authentication.

## Features

- **JWT Authentication** with role-based access control
- **Admin Role**: Full CRUD operations on products
- **Staff Role**: View products and update stock quantities only
- **Responsive React Frontend** with search functionality
- **SQLite Database** for data persistence

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
cd backend
2. Install dependencies:
npm install
3.Start the server:
npm run dev
The backend will run on http://localhost:5000

#### Frontend Setup

1. Navigate to the frontend directory:
cd frontend
2. Install dependencies:
npm install
3. Start the development server:
npm run dev
The frontend will run on http://localhost:3000