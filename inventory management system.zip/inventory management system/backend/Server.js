const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'your-secret-key-here';
const JWT_EXPIRES_IN = '1h';

app.use(cors());
app.use(express.json());

// Initialize SQLite Database
const db = new sqlite3.Database('./inventory.db');

// Create tables and seed data
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE,
    passwordHash TEXT,
    role TEXT CHECK(role IN ('ADMIN', 'STAFF'))
  )`);

  // Products table
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    quantity INTEGER DEFAULT 0,
    price REAL DEFAULT 0,
    category TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Seed admin and staff users
  const adminPassword = bcrypt.hashSync('admin123', 10);
  const staffPassword = bcrypt.hashSync('staff123', 10);
  
  db.run(`INSERT OR IGNORE INTO users (id, username, passwordHash, role) VALUES (?, ?, ?, ?)`,
    [uuidv4(), 'admin', adminPassword, 'ADMIN']);
  
  db.run(`INSERT OR IGNORE INTO users (id, username, passwordHash, role) VALUES (?, ?, ?, ?)`,
    [uuidv4(), 'staff', staffPassword, 'STAFF']);

  // Seed sample products
  db.run(`INSERT OR IGNORE INTO products (id, name, quantity, price, category) VALUES (?, ?, ?, ?, ?)`,
    [uuidv4(), 'Laptop', 15, 999.99, 'Electronics']);
  db.run(`INSERT OR IGNORE INTO products (id, name, quantity, price, category) VALUES (?, ?, ?, ?, ?)`,
    [uuidv4(), 'Desk Chair', 8, 149.99, 'Furniture']);
});

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Role-based Authorization Middleware
const requireRole = (role) => {
  return (req, res, next) => {
    if (req.user.role !== role) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
};

// Login endpoint
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role
      }
    });
  });
});

// Get all products
app.get('/products', authenticateToken, (req, res) => {
  const { search } = req.query;
  let query = 'SELECT * FROM products';
  let params = [];

  if (search) {
    query += ' WHERE name LIKE ? OR category LIKE ?';
    params = [`%${search}%`, `%${search}%`];
  }

  db.all(query, params, (err, products) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(products);
  });
});

// Add new product (Admin only)
app.post('/products', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const { name, quantity, price, category } = req.body;

  if (!name || quantity === undefined || price === undefined) {
    return res.status(400).json({ error: 'Name, quantity, and price are required' });
  }

  const product = {
    id: uuidv4(),
    name,
    quantity: parseInt(quantity),
    price: parseFloat(price),
    category: category || 'Uncategorized'
  };

  db.run(
    'INSERT INTO products (id, name, quantity, price, category) VALUES (?, ?, ?, ?, ?)',
    [product.id, product.name, product.quantity, product.price, product.category],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to create product' });
      }
      res.status(201).json(product);
    }
  );
});

// Update product (Staff can only update quantity, Admin can update all fields)
app.put('/products/:id', authenticateToken, (req, res) => {
  const productId = req.params.id;
  const { name, quantity, price, category } = req.body;

  db.get('SELECT * FROM products WHERE id = ?', [productId], (err, product) => {
    if (err || !product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    let updateFields = [];
    let updateValues = [];

    if (req.user.role === 'ADMIN') {
      // Admin can update all fields
      if (name !== undefined) {
        updateFields.push('name = ?');
        updateValues.push(name);
      }
      if (quantity !== undefined) {
        updateFields.push('quantity = ?');
        updateValues.push(parseInt(quantity));
      }
      if (price !== undefined) {
        updateFields.push('price = ?');
        updateValues.push(parseFloat(price));
      }
      if (category !== undefined) {
        updateFields.push('category = ?');
        updateValues.push(category);
      }
    } else {
      // Staff can only update quantity
      if (quantity !== undefined) {
        updateFields.push('quantity = ?');
        updateValues.push(parseInt(quantity));
      } else {
        return res.status(403).json({ error: 'Staff can only update quantity' });
      }
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    updateValues.push(productId);

    const query = `UPDATE products SET ${updateFields.join(', ')} WHERE id = ?`;

    db.run(query, updateValues, function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to update product' });
      }

      db.get('SELECT * FROM products WHERE id = ?', [productId], (err, updatedProduct) => {
        if (err) {
          return res.status(500).json({ error: 'Failed to fetch updated product' });
        }
        res.json(updatedProduct);
      });
    });
  });
});

// Delete product (Admin only)
app.delete('/products/:id', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const productId = req.params.id;

  db.run('DELETE FROM products WHERE id = ?', [productId], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Failed to delete product' });
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ message: 'Product deleted successfully' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});