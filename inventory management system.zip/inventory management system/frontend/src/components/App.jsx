// Remove this line:
const API_BASE = 'http://localhost:5000'

// Update all API calls to use proxy:
const response = await axios.get(`/api/products`, {
// Instead of:
const response = await axios.get(`${API_BASE}/products`, {