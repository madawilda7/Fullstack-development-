import React, { useState } from 'react'

const ProductItem = ({ product, userRole, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false)
  const [quantity, setQuantity] = useState(product.quantity)

  const handleUpdate = () => {
    onUpdate(product.id, { quantity: parseInt(quantity) })
    setIsEditing(false)
  }

  const handleCancel = () => {
    setQuantity(product.quantity)
    setIsEditing(false)
  }

  return (
    <tr>
      <td>{product.name}</td>
      <td>{product.category}</td>
      <td>
        {isEditing ? (
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            style={{ width: '80px' }}
          />
        ) : (
          product.quantity
        )}
      </td>
      <td>${product.price}</td>
      <td>
        {userRole === 'ADMIN' && !isEditing && (
          <>
            <button
              className="btn btn-secondary"
              onClick={() => setIsEditing(true)}
              style={{ marginRight: '0.5rem' }}
            >
              Edit
            </button>
            <button
              className="btn btn-danger"
              onClick={() => onDelete(product.id)}
            >
              Delete
            </button>
          </>
        )}
        {userRole === 'STAFF' && !isEditing && (
          <button
            className="btn btn-secondary"
            onClick={() => setIsEditing(true)}
          >
            Update Stock
          </button>
        )}
        {isEditing && (
          <>
            <button
              className="btn btn-primary"
              onClick={handleUpdate}
              style={{ marginRight: '0.5rem' }}
            >
              Save
            </button>
            <button
              className="btn btn-secondary"
              onClick={handleCancel}
            >
              Cancel
            </button>
          </>
        )}
      </td>
    </tr>
  )
}

export default ProductItem