import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LoginForm from './components/Login';

function App() {
  const [user, setUser] = useState(null);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingProduct, setEditingProduct] = useState(null);
  const [newProduct, setNewProduct] = useState({ name: '', quantity: 0, price: 0, category: '' });

  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (token && savedUser) {
      setUser(JSON.parse(savedUser));
      fetchProducts(token);
    }
  }, []);

  const fetchProducts = async (token = localStorage.getItem('token')) => {
    try {
      const response = await axios.get(`/api/products?search=${searchTerm}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
      if (error.response?.status === 401) {
        handleLogout();
      }
    }
  };

  const handleLogin = (loginData) => {
    const { token, user } = loginData;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setUser(user);
    fetchProducts(token);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setProducts([]);
  };

  const handleCreateProduct = async () => {
    try {
      await axios.post('/api/products', newProduct, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setNewProduct({ name: '', quantity: 0, price: 0, category: '' });
      fetchProducts();
    } catch (error) {
      alert('Failed to create product: ' + (error.response?.data?.error || 'Unknown error'));
    }
  };

  const handleUpdateProduct = async (productId, updates) => {
    try {
      await axios.put(`/api/products/${productId}`, updates, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setEditingProduct(null);
      fetchProducts();
    } catch (error) {
      alert('Failed to update product: ' + (error.response?.data?.error || 'Unknown error'));
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    
    try {
      await axios.delete(`/api/products/${productId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      fetchProducts();
    } catch (error) {
      alert('Failed to delete product: ' + (error.response?.data?.error || 'Unknown error'));
    }
  };

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>Inventory Management System</h1>
        <div className="user-info">
          Welcome, {user.username} ({user.role})
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </header>

      <div className="container">
        {user.role === 'ADMIN' && (
          <div className="create-product">
            <h3>Add New Product</h3>
            <input
              type="text"
              placeholder="Product Name"
              value={newProduct.name}
              onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
            />
            <input
              type="number"
              placeholder="Quantity"
              value={newProduct.quantity}
              onChange={(e) => setNewProduct({...newProduct, quantity: parseInt(e.target.value)})}
            />
            <input
              type="number"
              step="0.01"
              placeholder="Price"
              value={newProduct.price}
              onChange={(e) => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
            />
            <input
              type="text"
              placeholder="Category"
              value={newProduct.category}
              onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
            />
            <button onClick={handleCreateProduct}>Add Product</button>
          </div>
        )}

        <div className="search-bar">
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button onClick={fetchProducts}>Search</button>
        </div>

        <div className="products-grid">
          {products.map(product => (
            <div key={product.id} className="product-card">
              {editingProduct?.id === product.id ? (
                <ProductEditForm
                  product={product}
                  userRole={user.role}
                  onSave={handleUpdateProduct}
                  onCancel={() => setEditingProduct(null)}
                />
              ) : (
                <ProductView
                  product={product}
                  userRole={user.role}
                  onEdit={() => setEditingProduct(product)}
                  onDelete={handleDeleteProduct}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ProductView({ product, userRole, onEdit, onDelete }) {
  return (
    <>
      <h4>{product.name}</h4>
      <p>Quantity: {product.quantity}</p>
      <p>Price: ${product.price}</p>
      <p>Category: {product.category}</p>
      <div className="product-actions">
        <button onClick={onEdit}>
          {userRole === 'STAFF' ? 'Update Stock' : 'Edit'}
        </button>
        {userRole === 'ADMIN' && (
          <button onClick={() => onDelete(product.id)} className="delete-btn">
            Delete
          </button>
        )}
      </div>
    </>
  );
}

function ProductEditForm({ product, userRole, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    quantity: product.quantity,
    ...(userRole === 'ADMIN' && {
      name: product.name,
      price: product.price,
      category: product.category
    })
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(product.id, formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      {userRole === 'ADMIN' && (
        <>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
          <input
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
            required
          />
          <input
            type="text"
            value={formData.category}
            onChange={(e) => setFormData({...formData, category: e.target.value})}
          />
        </>
      )}
      <input
        type="number"
        value={formData.quantity}
        onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value)})}
        required
      />
      <div className="form-actions">
        <button type="submit">Save</button>
        <button type="button" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

export default App;